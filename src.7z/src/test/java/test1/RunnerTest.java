package test1;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;


@CucumberOptions(
        features = "src/test/resources/",
        glue = {""},
        plugin = {"pretty", "html:cucumber",
                "junit:junit"},
        monochrome = true)

@RunWith(CustomCucumberRunner.class)

public class RunnerTest {
	
	
    @BeforeSuite
    public static void test() throws Exception {
        FeatureOverright.overrideFeatureFiles("./src/test/resources");

    }
}

